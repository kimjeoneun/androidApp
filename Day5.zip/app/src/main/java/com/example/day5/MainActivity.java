package com.example.day5;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText editName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editName = findViewById(R.id.editName);

        Button btnActB = findViewById(R.id.btnActivityB);
        btnActB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ActivityB.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        callToast("onCreat 호출");
    }

    @Override
    protected void onStart() {
        super.onStart();
        callToast("onStart 호출");
    }

    @Override
    protected void onStop() {
        super.onStop();
        callToast("onStop 호출");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        callToast("onDestroy 호출");

        clearStat();
    }

    private void clearStat() {
        SharedPreferences pref = getSharedPreferences("pref", Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.clear();
        editor.commit();
    }

    @Override
    protected void onPause() {
        super.onPause();
        callToast("onPause 호출");

        saveState();
    }

    private void saveState() {
        SharedPreferences pref = getSharedPreferences("pref", Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("name", editName.getText().toString());
        editor.commit();
    }

    @Override
    protected void onResume() {
        super.onResume();
        callToast("onResume 호출");

        restoreState();
    }

    //입력상자에 데이터 복원
    private void restoreState() {
        SharedPreferences pref = getSharedPreferences("pref", Activity.MODE_PRIVATE);
        if((pref != null) && (pref.contains("name"))){
            String name = pref.getString("name", "");
            editName.setText(name);
        };
    }

    private void callToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        Log.d("MyApp", msg);
    }
}
